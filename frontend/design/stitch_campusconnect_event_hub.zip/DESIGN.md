---
name: Vibrant Collegiate
colors:
  surface: '#f9f9ff'
  surface-dim: '#cedbf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff3ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d7e3fa'
  on-surface: '#101c2d'
  on-surface-variant: '#46464e'
  inverse-surface: '#253143'
  inverse-on-surface: '#ebf1ff'
  outline: '#76767e'
  outline-variant: '#c6c5ce'
  surface-tint: '#555d7f'
  primary: '#000006'
  on-primary: '#ffffff'
  primary-container: '#121a38'
  on-primary-container: '#7b83a6'
  inverse-primary: '#bdc5ec'
  secondary: '#4500e8'
  on-secondary: '#ffffff'
  secondary-container: '#5f39fe'
  on-secondary-container: '#e2dcff'
  tertiary: '#030000'
  on-tertiary: '#ffffff'
  tertiary-container: '#3e0600'
  on-tertiary-container: '#ed4a27'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#bdc5ec'
  on-primary-fixed: '#121a38'
  on-primary-fixed-variant: '#3e4566'
  secondary-fixed: '#e5deff'
  secondary-fixed-dim: '#c8bfff'
  on-secondary-fixed: '#190064'
  on-secondary-fixed-variant: '#4100db'
  tertiary-fixed: '#ffdad3'
  tertiary-fixed-dim: '#ffb4a4'
  on-tertiary-fixed: '#3d0600'
  on-tertiary-fixed-variant: '#8c1800'
  background: '#f9f9ff'
  on-background: '#101c2d'
  surface-variant: '#d7e3fa'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 44px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: '0'
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system positions campus life at the intersection of spirited collegiate heritage and frictionless social discovery. It targets active undergraduate and graduate students, campus organization leads, and student affairs curators who demand instant, vibrant access to campus culture without institutional friction.

The visual direction merges **Modern Collegiate** with **Contemporary Community Glassmorphism**. Clean, expansive surfaces are anchored by deep collegiate foundations, energized by electric accents, and layered with frosted translucent surfaces that keep dense campus schedules feeling open, light, and alive. The emotional tone is energetic, welcoming, inclusive, and socially magnetic.

## Colors
The palette balances institutional prestige with high-voltage social energy:
- **Primary (`#121A38`)**: Deep Academic Navy. Serves as the ground truth for brand anchors, high-contrast headline text, primary navigation frames, and high-impact hero action states.
- **Secondary (`#5A32FA`)**: Electric Indigo-Violet. The kinetic pulse of the UI, powering interactive active states, live indicators, focused states, and prominent primary calls-to-action.
- **Tertiary (`#FF5733`)**: Warm Radiant Coral/Amber. Reserved for real-time urgency, RSVP deadlines, hot campus trends, active badge pings, and bookmark alerts.
- **Neutral (`#626E82`)**: Slate Midtone. Complemented by clean off-white canvas values (`#F8FAFC` base surface) and layered translucent slate borders (`rgba(98, 110, 130, 0.14)`) to establish legibility and hierarchy without harsh black-and-white disparity.

## Typography
Plus Jakarta Sans drives the entire typographic scale, combining geometric precision with warm, contemporary humanist curves suited for event discovery.
- Use tight letter spacing on `display` and `headline` levels to maintain density and editorial impact.
- Reserve `label-sm` in all-caps uppercase styling strictly for category badges, dates, and live status labels.
- For running descriptive text in event descriptions, utilize `body-lg` or `body-md` with regular weights (`400`) to guarantee high sustained readability over varying translucent backgrounds.

## Layout & Spacing
The layout follows a 12-column responsive fluid grid on desktop screen sizes, an 8-column layout on tablet, and a 4-column layout on mobile.
- **Desktop (1024px+)**: 12 columns with 1.25rem (`20px`) gutters and a max-container boundary set to 1280px with 2rem outer margins.
- **Tablet (768px - 1023px)**: 8 columns with 1rem gutters and 1.5rem margins.
- **Mobile (< 768px)**: 4 columns with 0.75rem gutters and 1rem margins.

Grid columns reflow from a 3-card event layout on desktop to a 2-card row on tablet, collapsing to single-card full-width stacks on mobile screens. Keep section gaps governed by `space-xl` while intra-component padding remains strictly disciplined across `space-sm` to `space-md`.

## Elevation & Depth
Visual depth relies on a synthesis of **frosted glassmorphism**, soft perimeter strokes, and colored ambient dissipation:
- **Level 1 (Event Cards, Input Shells)**: Translucent surface fill `rgba(255, 255, 255, 0.75)` supported by a `12px` backdrop blur, bound by an interior border `1px solid rgba(255, 255, 255, 0.8)` and exterior shadow `0 8px 24px -4px rgba(18, 26, 56, 0.06)`.
- **Level 2 (Hover States, Floating Quick-Filters)**: Backdrop blur increases to `16px` with surface fill `rgba(255, 255, 255, 0.85)`, lifted by an ambient shadow `0 16px 36px -6px rgba(90, 50, 250, 0.12)`.
- **Level 3 (Modals, Sheet Drawers, Flyout Menus)**: Solid/semi-opaque surface `rgba(255, 255, 255, 0.95)` with backdrop blur `24px`, offset by `0 24px 48px -12px rgba(18, 26, 56, 0.18)` and an accented violet border tint `1px solid rgba(90, 50, 250, 0.16)`.

## Shapes
The shape language uses balanced rounded geometries (Level 2).
- Standard UI targets (buttons, search inputs, input controls): `0.5rem` (8px).
- Event discovery cards, modals, and container surfaces: `rounded-lg` at `1rem` (16px).
- Large media wrappers, hero banners, and floating sheets: `rounded-xl` at `1.5rem` (24px).
- Category badges, live tags, and avatar pill wrappers: Fully rounded capsules (9999px) for friendly, high-contrast scanning.

## Components

### Buttons
- **Primary**: High-contrast fill using `#5A32FA` with pure white text, 8px radius, bold label typography. Interactive states feature a subtle top reflection highlight and an ambient violet glow on hover.
- **Secondary / Ghost**: Translucent glass background `rgba(255, 255, 255, 0.6)` with `1px solid rgba(98, 110, 130, 0.2)` border and `#121A38` text.
- **Urgent / RSVP CTA**: Tertiary coral `#FF5733` fill with white text, utilized exclusively for limited-capacity events or immediate attendance confirmation.

### Category Chips & Badges
- Capsule pills (9999px border radius) featuring low-opacity tinted fills corresponding to campus verticals (e.g., Violet for Greek Life/Social, Coral for Athletics, Slate for Academic).
- Typography: `label-sm` with active states shifting from a subtle border to a solid primary or secondary background fill with crisp white text.

### Event Cards
- Built using Level 1 Glassmorphism. Aspect ratio 16:9 media cover at top, followed by date/time badges stacked over `title-md` headlines.
- Bottom metadata includes attendance counters, host avatar, and a quick-save bookmark button with micro-interactions.

### Search & Filter Inputs
- Polished, pill-soft inputs (`0.5rem` radius) with `rgba(255, 255, 255, 0.8)` background, slate placeholder text, and an electric indigo focus ring (`2px solid #5A32FA`).
- Integrated left-hand search icon and right-hand clear/filter shortcut chips.

### Checkboxes & Radios
- Crisp `18px` squares/circles with `2px` borders in neutral slate. Active selection fills with `#5A32FA` alongside an animated white checkmark.

### Quick Attendance Toggles
- Custom segmented control tabs embedded directly within navigation headers and event overlays, utilizing soft backdrop filters and active slider pills to toggle between "All Events", "My Campus", and "Saved".